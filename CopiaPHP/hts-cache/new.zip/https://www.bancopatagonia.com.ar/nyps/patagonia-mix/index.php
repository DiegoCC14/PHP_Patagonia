<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->		
		<!-- METATAGS -->
		<title>¡Descubrí Patagonia MIX! | Banco Patagonia</title>
		<meta name="description" content="La combinación perfecta entre tu vida personal y tu negocio.">
		
		<!-- Google -->
		<meta name="thumbnail" content="https://www.bancopatagonia.com.ar/nyps/patagonia-mix/images/patagonia-mix.jpg" />

		<!-- Open Graph / Facebook -->
		<meta property="og:type" content="website">
		<meta property="og:url" content="">
		<meta property="og:title" content="¡Descubrí Patagonia MIX!">
		<meta property="og:description" content="La combinación perfecta entre tu vida personal y tu negocio.">
		<meta property="og:image" content="https://www.bancopatagonia.com.ar/nyps/patagonia-mix/images/head-patagonia-mix-mbl.jpg">

		<!-- Twitter -->
		<meta property="twitter:card" content="summary_large_image">
		<meta property="twitter:url" content="">
		<meta property="twitter:title" content="¡Descubrí Patagonia MIX!">
		<meta property="twitter:description" content="La combinación perfecta entre tu vida personal y tu negocio.">
		<meta property="twitter:image" content="https://www.bancopatagonia.com.ar/nyps/patagonia-mix/images/head-patagonia-mix-mbl.jpg">		
		
        <!-- SLIDES RESPONSIVE -->
        <style>
			/* DSK */
			#head-patagonia-mix { background-image: url(images/head-patagonia-mix-dsk.jpg); background-image: -webkit-image-set ( url("images/head-patagonia-mix-dsk.jpg") 1x, url("images/head-patagonia-mix-dsk@2x.jpg") 2x ); }

			@media screen and (max-width: 1200px) {
				/* TBT */
				#head-patagonia-mix { background-image: url(images/head-patagonia-mix-tbl.jpg); background-size: auto !important; background-image: -webkit-image-set ( url("images/head-patagonia-mix-tbl.jpg") 1x, url("images/head-patagonia-mix-tbl@2x.jpg") 2x ); }
			}
			@media screen and (max-width: 560px) {
				/* MBL */
				#head-patagonia-mix { background-image: url(images/head-patagonia-mix-mbl.jpg); background-image: -webkit-image-set ( url("images/head-patagonia-mix-mbl.jpg") 1x, url("images/head-patagonia-mix-mbl@2x.jpg") 2x ); }
			}
		</style>
		
		<!-- CSS -->
        <style>
			.text-data h1, .text-data h2, .text-data h3 { color: #001641; }
			.text-data h1 { font-size: 36px; line-height: 1em; margin-bottom: 10px; font-family: "Roboto-Regular"; }
			.text-data h2 { font-size: 26px; }
			.text-data h3.pmix-h3 { font-size: 20px; }
			
			/* MEJORES BENEFICIOS */
			.bnf-box { justify-content: center; align-items: center; }
			.bnf-box .bnf-card { margin-bottom: 0; }
			.bnf-box .bnf-card-data img { width: 140px; margin-top: 10px; display: block; }
			
			/* WAPA */
			#box-radius-wapa.box-radius-sect .box-radius { height: 184px; }
			.box-radius-sect .box-radius .box-radius-flex { display: flex; align-items: center; justify-content: center; column-gap: 15px; }
			.box-radius-sect .box-radius img.box-radius-flex-icon { height: 85px; }
			
			/* LOGOS */
			img.pmix-payway-logo { height: 35px; margin: 0 auto 15px auto; display: table; }
			
			/* BENEFICIOS */
			#pmix-bnf #pmix-placa { margin: 0 auto 30px auto; border-radius: 25px; }
			#pmix-bnf h3 { margin-bottom: 5px; }
			#pmix-bnf ul { margin-bottom: 0px; }
			#pmix-bnf hr { margin-top: 15px; margin-bottom: 15px; }
			/*#pmix-bnf p { margin-bottom: 30px; }*/
			#pmix-bnf .pmix-bnf-icon { display: flex; align-items: center; column-gap: 10px; margin: 10px 0; }
			#pmix-bnf .pmix-bnf-icon img { height: 40px; }
			#pmix-bnf .pmix-bnf-icon p { margin-bottom: 0; }
			
			/* BOTÓN */
			a.tmpl-jubi-btn#pmix-btn-bnf { margin: 15px 0; background: #001641; color: #a9dd00; }/* parche */
			
			@media screen and (max-width: 1200px) {
				.text-data h1 { font-size: 26px; }
				.text-data h2 { font-size: 20px; }
				.text-data h3.pmix-h3 { font-size: 16px; }
            }
			
			@media screen and (max-width: 700px) {
				.bnf-box .bnf-card, .bnf-box .bnf-card-data, .bnf-box .bnf-card-data img { display: table; margin-left: auto; margin-right: auto; }
				.bnf-box .bnf-card { margin-bottom: 10px; }
				.bnf-box .bnf-card-data p { display: block; text-align: center;}
            }
			
			@media screen and (max-width: 550px) {
				#box-radius-wapa.box-radius-sect .box-radius { height: auto; }
			}
			
		</style>
        <!-- -->
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                								<li><a href="../../preguntas-frecuentes/index.php" class="">Ayuda</a></li>
								<!--<li><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>">Canales de atención</a></li>-->
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <!--<li><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>">Ayuda</a></li>-->
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../../personas/index.php" class="">PERSONAS</a></li>
								<li><a href="../index.php" class="active">PROFESIONALES Y COMERCIOS</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
						                        
                        						<!-- NYPS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                                <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                                <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                                <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                                <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                                <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                                <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
								<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
							</ul>
						</li>
						<!-- FIN NYPS -->					
						                        
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../personas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
						<li><a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/" target="_blank">Beneficios</a></li>
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<!--<li><a href="<php echo $path ?>personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>-->
						<li><a href="../../personas/cuotifica-al-toque.php">Cuotificá al Toque</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/jubilados/index.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
						<li><a href="../../personas/plan-sueldo/index.php">Patagonia Sueldo</a></li>
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/seguros/index.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PROFESIONALES Y COMERCIOS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/seguros/index.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>-->
                        <!--<li><a href="<php echo $path ?>nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <!--<li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>-->
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BENEFICIOS RÍO NEGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/rio-negro/presencia.php">Presencia en Río Negro</a></li>
                        <li><a href="../../sector-publico/rio-negro/propuesta-valor.php">Propuesta de valor exclusiva</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        		<li class="nav-main-item"><a href="../../preguntas-frecuentes/index.php" class="" style="text-transform: none;">Ayuda</a></li>
		<!--<li class="nav-main-item"><a href="<php echo $folder_canales ?>index.php" class="<php echo $canales ?>" style="text-transform: none;">Canales de Atención</a></li>-->
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <!--<li class="nav-main-item"><a href="<php echo $path ?>ayuda/index.php" class="<php echo $ayuda ?>" style="text-transform: none;">Ayuda</a></li>-->
	</ul>
</div>	<!--<section class="sec-head" title="¡Descuento exclusivo en todos los planes de salud de Swiss Medical! 25% en los primeros 3 meses. Sin tope. Conocé más">-->
	<section class="sec-head" title="¡Descubrí Patagonia MIX! La combinación perfecta entre tu vida personal y tu negocio">
        <div class="sec-pic-head" id="head-patagonia-mix">
		</div>
	</section>
	    <section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="index.php">Profesionales y Comercios</a></li>
					<li class="active">Patagonia MIX</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
		<div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-data">
					<!-- ------------- -->
					<!-- BOTÓN FLOTADO -->
					<!-- ------------- -->
					<!-- "#sueldo" para ancla en botones CTA -->
					<a href="https://bp.bancopatagonia.com.ar/solicitud-de-contacto" target="_blank" class="tmpl-jubi-btn" id="tmpl-jubi-btn-fxd">QUIERO SER MIX<!--<span><em>+</em> info</span>--></a>
					<!-- ------ -->
					<!-- TÍTULO -->
					<!-- ------ -->
					<h1 class="text-center">Empezá a acreditar tus ventas con nosotros y te regalamos <br class="dsk"><strong class="clr-verde-2">Hasta $250.000</strong> en tu cuenta</h1>
					<h3 class="pmix-h3 text-center">¡Visítanos en tu sucursal más cercana y forma parte de la experiencia MIX! <sup>(1)</sup></h3>
					<!-- --------- -->
					<!-- SEGMENTOS -->
					<!-- --------- -->
					<hr>
					<!-- -->
                    <h2 class="text-center"><strong>Elegí el paquete de productos perfecto para vos</strong></h2>
					<h3 class="pmix-h3 text-center clr-verde-2"><strong>Disfrútalo 100% bonificado los primeros 6 meses</strong><br class="dsk"> ¡y luego seguí bonificando por transaccionalidad! <sup>(2)</sup></h3>
					<!-- -->
					<div class="row box-radius-sect">
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="box-radius box-radius-segm">
								<img class="box-radius-segm-logo" id="box-radius-segm-logo-sing" src="../../assets/images/layout/logo-patagonia-singular.svg" alt="Patagonia Simgular">
								<figure class="box-radius-cards">
									<img class="box-radius-card-visa" src="../../assets/images/layout/tarjetas/visa-signature.png" alt="Tarjeta Visa Signature"/>
									<img class="box-radius-card-master" src="../../assets/images/layout/tarjetas/master-black.png" alt="Tarjeta Mastercard Black"/>
								</figure>
								<ul>
									<li>Tarjetas Black.</li>
									<li>Caja de ahorro en pesos, dólares y euros.</li>
									<li>Cuenta corriente.</li>
									<li>Acceso a salas VIP en aeropuertos.</li>
								</ul>
								<a class="box-radius-lnk" href="../patagonia-singular/paquete/propuesta.php"><em>+</em> <span>Ver Más</span></a>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="box-radius box-radius-segm">
								<img class="box-radius-segm-logo" src="../../assets/images/layout/logo-patagonia-plus.svg" alt="Patagonia Plus">
								<figure class="box-radius-cards">
									<img class="box-radius-card-visa" src="../../assets/images/layout/tarjetas/visa-platinum.png" alt="Tarjeta Visa Platinum"/>
									<img class="box-radius-card-master" src="../../assets/images/layout/tarjetas/master-platinum.png" alt="Tarjeta Mastercard Platinum"/>
								</figure>
								<ul>
									<li>Tarjetas Platinum/Gold.</li>
									<li>Caja de ahorro en pesos, dólares y euros.</li>
									<li>Cuenta corriente.</li>
								</ul>
								<a class="box-radius-lnk" href="../patagonia-plus/productos.php"><em>+</em> <span>Ver Más</span></a>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="box-radius box-radius-segm">
								<img class="box-radius-segm-logo" src="../../assets/images/layout/logo-patagonia-clasica.svg" alt="Patagonia Clásica">
								<figure class="box-radius-cards">
									<img class="box-radius-card-visa" src="../../assets/images/layout/tarjetas/visa-clasica.png" alt="Tarjeta Visa Classic"/>
									<img class="box-radius-card-master" src="../../assets/images/layout/tarjetas/master-clasica.png" alt="Tarjeta Mastercard Internacional"/>
								</figure>
								<ul>
									<li>Tarjetas Internacionales.</li>
									<li>Caja de ahorro en pesos, dólares y euros.</li>
									<li>Cuenta corriente.</li>
								</ul>
								<a class="box-radius-lnk" href="../patagonia-clasica/premium/productos.php"><em>+</em> <span>Ver Más</span></a>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-6">
							<div class="box-radius box-radius-segm">
								<img class="box-radius-segm-logo" src="../../assets/images/layout/logo-patagonia-emprendimiento.svg" alt="Patagonia Emprendimiento">
								<!--<p class="text-center" style="margin-bottom: 25px;"><strong>Patagonia Emprendimiento</strong></p>-->
								<figure class="box-radius-cards">
									<img class="box-radius-card-visa" style="left: 20px;" src="../../assets/images/layout/tarjetas/visa-debito.png" alt="Tarjeta Visa Débito"/>
								</figure>
								<ul>
									<li>Tarjeta de debito.</li>
									<li>Caja de ahorro en pesos, dólares y euros.</li>
									<li>Cuenta corriente.</li>
								</ul>
								<a class="box-radius-lnk" href="../patagonia-clasica/patagonia-emprendimiento/productos.php"><em>+</em> <span>Ver Más</span></a>
							</div>
						</div>
					</div>
					<!-- --------- -->
					<!-- BENEFICIO -->
					<!-- --------- -->
					<hr>
					<!-- -->
					<h2 class="text-center"><strong>Accede a este beneficio exclusivo por ser parte de Cuenta <img style="height: 22.5px; margin: -8px 0px 0px 0px;" src="images/logo-mix.svg" alt="Mix"> </strong></h2>
					<!-- -->
					<!-- PROMOCION -->
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<!-- -->
							<div class="bnf-box bnf-singular">
								<div class="bnf-card">
									<!--<i class="bnf-icon bnf-icon-shop"></i>-->
									<!--<i class="bnf-misc"></i>-->
									<p>&nbsp;</p>
									<big>25<span>%<sup>(3)</sup></span></big>
									<p>de descuento</p>
								</div>
								<div class="bnf-card-data">
									<p><strong>En los primeros tres meses de contratación.</strong></p>
									<p>Cuidá tu salud con</p>
									<img src="../../assets/images/layout/logos/logo-swiss-medical.svg" alt="Logo Swiss Medical">
								</div>
							</div>
							<!-- TEXTO -->
							<div class="row">
								<div class="col-md-12 col-sm-12 col-xs-12">
									<p class="clr-singular; text-center" style="margin: 10px 0px 0px 0px;">Exclusivo para nuevos clientes Swiss Medical</p>
								</div>
							</div>
						</div>
					</div>
					<!-- ---- -->
					<!-- WAPA -->
					<!-- ---- -->
					<hr>
					<!-- -->
					<h2 class="text-center"><strong>Llevá tu negocio a otro nivel con nuestras soluciones de cobros</strong></h2>
					<!-- -->
					<div id="box-radius-wapa" class="row box-radius-sect">
						<div class="col-md-4 col-sm-12 col-xs-12">
							<div class="box-radius box-radius-nobrd">
								<h3 class="pmix-h3">Banco Patagonia creó <strong>WAPA!</strong></h3>
								<div class="box-radius-flex">
									<img class="box-radius-flex-icon" src="../../assets/images/layout/logo-wapa.svg" alt="WAPA"/>
									<div>
										<p>Para brindarte nuevas formas de cobro y operar sin costos fijos de mantenimiento.</p>
										<p><a href="#wapa" data-toggle="modal">Conoce más</a></p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-6">
							<div class="box-radius">
								<h3 class="pmix-h3 text-center">Links de Pago</h3>
								<div class="box-radius-flex">
									<!--<img class="box-radius-flex-icon" src="images/icon-links-pago.svg" alt="Links de Pago">-->
									<p>Lo compartís por WhatsApp, email o redes sociales y recibís pagos desde cualquier lugar.</p>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-6">
							<div class="box-radius box-radius-last">
								<h3 class="pmix-h3 text-center">Lector de Tarjetas</h3>
								<div class="box-radius-flex">
									<img class="box-radius-flex-icon" src="images/icon-lector-tarjetas.png" alt="Lector de Tarjetas">
									<p>Cobra con tu lector y acepta tarjetas de crédito y débito de las principales marcas.</p>
								</div>
							</div>
						</div>
					</div>
					<!-- ------ -->
					<!-- PAYWAY -->
					<!-- ------ -->
					<hr>
					<!-- -->
					<img class="pmix-payway-logo" src="../../assets/images/layout/logo-payway.svg" alt="Payway"/>
					<h3 class="pmix-h3 text-center">Aprovechá el kit de soluciones para gestionar y potenciar tu negocio</h3>
					<!-- -->
					<div class="row box-radius-sect mb40-h">
						<div class="col-md-4 col-sm-6 col-xs-6">
							<div class="box-radius">
								<h3 class="pmix-h3 text-center">Terminales Smart</h3>
								<div class="box-radius-flex">
									<img class="box-radius-flex-icon" src="images/icon-terminales-smart.svg" alt="Terminales Smart">
									<p>Cobrá rápido y simple con todos los medios de pago.</p>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-6">
							<div class="box-radius">
								<h3 class="pmix-h3 text-center">Cobros con QR</h3>
								<div class="box-radius-flex">
									<img class="box-radius-flex-icon" src="images/icon-cobros-qr.svg" alt="Cobros con QR">
									<p>Aceptá todas las billeteras virtuales y apps bancarias.</p>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-6">
							<div class="box-radius box-radius-last">
								<h3 class="pmix-h3 text-center">Cobro Anticipado</h3>
								<div class="box-radius-flex">
									<img class="box-radius-flex-icon" src="images/icon-cobro-anticipado.svg" alt="Cobro Anticipado">
									<p>Recibí el dinero de tus ventas en 24hs hábiles.</p>
								</div>
							</div>
						</div>
					</div>
					<!-- ---------- -->
					<!-- BENEFICIOS -->
					<!-- ---------- -->
					<!--<hr>-->
					<div class="box-radius-sect mb30-h">
						<div class="box-radius box-radius-last">
							<!-- -->
							<h2 class="text-center"><strong>Además, contas con los siguientes beneficios</strong></h2>
							<!-- -->
							<div id="pmix-bnf" class="row">
								<div class="col-md-6 col-sm-12 col-xs-12">
									<img id="pmix-placa" alt="Patagonia MIX" src="images/patagonia-mix.jpg" srcset="images/patagonia-mix.jpg 1x, images/patagonia-mix@2x.jpg 2x" class="img-responsive">
								</div>
								<div class="col-md-6 col-sm-12 col-xs-12">
									<br>
									<h3 class="pmix-h3">☑ Oficial Exclusivo</h3>
									<p>Atención prioritaria para asesorarte y acompañarte.</p>
									<hr>
									<h3 class="pmix-h3">☑ Fondos Comunes de Inversión</h3>
									<p>Hace crecer tus ahorros.</p>
									<hr>
									<h3 class="pmix-h3">☑ Acceso Club Patagonia</h3>
									<p>Canjea tus puntos por increíbles premios.</p>
									<hr>
									<h3 class="pmix-h3">☑ Beneficios exclusivos</h3>
									<div class="row">
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="pmix-bnf-icon">
												<img src="../../assets/images/layout/icons/v4/icon-cart-v4.svg" alt="Supermercados">
												<p>Supermercados</p>
											</div>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="pmix-bnf-icon">
												<img src="../../assets/images/layout/icons/v4/icon-clothing-v4.svg" alt="Indumentaria">
												<p>Indumentaria</p>
											</div>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="pmix-bnf-icon">
												<img src="../../assets/images/layout/icons/v4/icon-delivery-v4.svg" alt="Delivery">
												<p>Delivery</p>
											</div>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="pmix-bnf-icon">
												<img src="../../assets/images/layout/icons/v4/icon-restaurant-v4.svg" alt="Gastronomía">
												<p>Gastronomía</p>
											</div>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="pmix-bnf-icon">
												<img src="../../assets/images/layout/icons/v4/icon-fuel-v4.svg" alt="Combustible">
												<p>Combustibles</p>
											</div>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="pmix-bnf-icon">
												<img src="../../assets/images/layout/icons/v4/icon-plane-v4.svg" alt="Viajes">
												<p>Viajes</p>
											</div>
										</div>
									</div>
									<!-- -->
									<a href="https://ahorrosybeneficios.bancopatagonia.com.ar/ahorrosybeneficios/" target="_blank" class="tmpl-jubi-btn" id="pmix-btn-bnf">Conocé todos los beneficios</a>
									<!-- -->
								</div>
							</div>
							<!-- -->
						</div>
					</div>
					<div class="row mb40-h">
						<div class="col-md-4 col-sm-4 col-xs-12 col-md-offset-4 col-sm-offset-4">
							<a href="https://bp.bancopatagonia.com.ar/solicitud-de-contacto" target="_blank" class="tmpl-jubi-btn">Quiero que me contacten</a>
						</div>
					</div>
                    <!-- ---- -->
					<!-- FAQS -->
					<!-- ---- -->
					<!--<hr>-->
					<!-- -->
					<h2 class="text-center"><strong>Preguntas Frecuentes</strong></h2>
					<!-- -->
					<div class="row">
						<!-- -- -->
						<!-- 01 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-pmix-01" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cómo me convierto en MIX?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-pmix-01">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3 class="pmix-h3"><strong>¿Cómo me convierto en MIX?</strong></h3>
											<p>Visítanos en la sucursal más cercana con tu  DNI, y  forma parte de la experiencia.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 02 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-pmix-02" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Qué significa que el paquete se encuentre bonificado por 6 meses?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-pmix-02">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3 class="pmix-h3"><strong>¿Qué significa que el paquete se  encuentre bonificado por 6 meses?</strong></h3>
											<p>Durante los primeros 6 (seis) meses no pagaras  el costo de mantenimiento.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 03 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-pmix-03" class="btn-faqs-dspl" data-toggle="modal"><i></i>Finalizada la bonificación de 6 meses ¿puedo mantener bonificada la comisión mensual?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-pmix-03">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3 class="pmix-h3"><strong>Finalizada la bonificación de 6 meses ¿puedo mantener bonificada la comisión mensual?</strong></h3>
											<p>Si, luego de los 6 meses podés mantener bonificada la comisión mensual por transaccionalidad</p>
											<ul>
												<li><a href="../patagonia-singular/paquete/bonifica-tu-paquete.php">Hace clic</a> y enterate como bonificar tu paquete Singular.</li>
												<li><a href="../patagonia-plus/bonifica-tu-paquete.php">Hace clic</a> y enterate como bonificar tu paquete Plus.</li>
												<li><a href="../patagonia-clasica/premium/bonifica-tu-paquete.php">Hace clic</a> y enterate como bonificar tu paquete Clasica.</li>
												<li><a href="../patagonia-clasica/patagonia-emprendimiento/bonifica-tu-paquete.php">Hace clic</a> y enterate como bonificar tu paquete Emprendimiento.</li>
											</ul>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 04 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-pmix-04" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cuáles son los requisitos para recibir el premio de bienvenida?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-pmix-04">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3 class="pmix-h3"><strong>¿Cuáles son los requisitos para recibir el premio de bienvenida?</strong></h3>
											<ul>
												<li>Comenzar a acreditar tus cupones de ventas  en Banco Patagonia</li>
												<li>No haber recibido un regalo de Bienvenida  previamente</li>
												<li>Cumplir con las acreditaciones mínimas  requeridas para acceder al premio de bienvenida.</li>
											</ul>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 05 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-pmix-05" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Cuál es el monto de regalo de Bienvenida que recibo por acreditar mis ventas en Patagonia?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-pmix-05">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3 class="pmix-h3"><strong>¿Cuál es el monto de regalo de Bienvenida que recibo por acreditar mis ventas en Patagonia?</strong></h3>
											<ul>
                                                <li>Si acreditas mensualmente $2.500.000 o más (en concepto de cupones de ventas) recibís $250.000 de regalo.</li>
												<li>Si acreditas mensualmente $1.600.000 o más (en concepto de cupones de ventas) recibís $160.000 de regalo.</li>
												<li>Si acreditas mensualmente $800.000 o más (en concepto de cupones de ventas) recibís $85.000 de regalo.</li>
												<li>Si acreditas mensualmente $360.000 o más (en concepto de cupones de ventas) recibís $40.000 de regalo.</li>
                                            </ul>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- -- -->
						<!-- 06 -->
						<!-- -- -->
						<!-- botón -->
						<div class="col-md-12 col-sm-12 col-xs-12">
							<a href="#faqs-pmix-06" class="btn-faqs-dspl" data-toggle="modal"><i></i>¿Dónde y cuándo me acreditan el regalo de Bienvenida?</a>
						</div>
						<!-- modal -->
						<div class="modal fade" id="faqs-pmix-06">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span>X</span></button>
									</div>
									<div class="modal-body">
										<div class="text-data">
											<!-- -->
											<h3 class="pmix-h3"><strong>¿Dónde y cuándo me acreditan el regalo de Bienvenida?</strong></h3>
                    						<p>El regalo de bienvenida lo recibirás en tu cuenta por única vez. El crédito se efectuará al mes siguiente de la segunda acreditación mensual de cupones dentro de los primeros 10 días hábiles. Para que el premio se haga efectivo deberás cumplir con los requisitos informados.</p>
											<!-- -->
										</div>
									</div>
								</div>
							</div>
						</div>
						<!---->
					</div>
					<!-- ----------- -->
					<!-- CONTACTANOS -->
					<!-- ----------- -->
					<hr>
					<h2 class="tmpl-jubi-title"><strong>Contactanos</strong></h2>
					<!---->
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-contact tmpl-jubi-contact-box-1">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-padi-circle.svg" alt="PADI">
								<h3><strong>Asistente Virtual PADI</strong></h3>
							</div>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-contact tmpl-jubi-contact-box-2">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-telefono-circle.svg" alt="Teléfono">
								<h3><strong>Telefónicamente<br> 0800-777-8500</strong></h3>
							</div>
							<!-- -->
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<!-- -->
							<div class="tmpl-jubi-contact tmpl-jubi-contact-box-3">
								<img class="tmpl-jubi-icon-circle" src="../../assets/images/layout/icons/jubilados/icon-sucursales-circle.svg" alt="Sucursales">
								<h3><strong>Sucursales</strong></h3>
							</div>
							<!-- -->
						</div>
					</div>
					<!-- -->
					<!-- -->
                </div>
            </div>
        </div>
    </section>
	
	<!-- PRE FOOTER -->
    <section class="container">
        <div class="row legal-int">
            <div class="col-md-12 col-sm-12 col-xs-12">
				<p>(1) CARTERA DE CONSUMO Y COMERCIAL PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/03/2024 HASTA EL 31/12/2025, AMBAS FECHAS INCLUIDAS PROMOCION VALIDA PARA CLIENTES TITULAES DE LOS PRODUCTOS CUENTAS MIX: SINGULAR MIX, PLUS MIX, CLASICA MIX Y EMPRENDIMIENTO. QUE ACREDITEN POR PRIMERA VEZ CUPONES DESDE LA VIGENCIA DE LA PROMOCIÓN. EL BENEFICIO CONSISTE EN UN CRÉDITO, POR ÚNICA VEZ, EN SU CUENTA VINCULADA A SU PRODUCTO PATAGONIA BAJO LA LEYENDA “Beneficio bienvenida MIX”. EL CRÉDITO SE EFECTUARÁ AL MES SIGUIENTE DE LA SEGUNDA ACREDITACION MENSUAL DE CUPONES DENTRO DE LOS PRIMEROS 10 DIAS HABILES, DEBE CUMPLIR CADA MES CON EL UMBRAL. EL CREDITO SE EFECTUARÁ LUEGO DE REALIZARSE LA EFECTIVA VERIFICACIÓN DE LOS SIGUIENTES MONTOS DE ACREDITACIÓN MENSUAL DE CUPONES DE TARJETA DE CRÉDITO/DÉBITO EN SU CUENTA, POR VENTAS COBRADAS A TRAVÉS DE WAPA, MODO O PAYWAY: i) ACREDITACION SUPERIOR A $2.500.000 MENSUAL PREMIO DE $250.000 ii) ACREDITACION DE $1.600.000 MENSUAL PREMIO DE $160.000 iii) ACREDITACION DE $800.000 MENSUAL PREMIO DE $85.000 iiii) ACREDITACION DE $360.000 MENSUAL PREMIO DE $40.000. DE NO CUMPLIR LOS REQUISITOS EN UN PLAZO MÁXIMO DE 60 DÍAS CORRIDOS Y CONTADOS A PARTIR DE LA PRIMERA ACREDITACIÓN, SE PERDERÁ EL DERECHO AL BENEFICIO INDICADO SIN QUE ELLO GENERE INDEMNIZACIÓN ALGUNA A FAVOR DEL CLIENTE. EL BANCO SE ENCONTRARÁ FACULTADO PARA DEBITAR DE LA CUENTA DE TITULARIDAD DEL CLIENTE, AÚN EN DESCUBIERTO, EL IMPORTE CORRESPONDIENTE AL BENEFICIO OPORTUNAMENTE ACREDITADO, SI ESTE NO MANTUVIESE LAS ACREDITACIONES MENSUALES Y CONSECUTIVAS POR UN PLAZO MÍNIMO DE 12 MESES.</p>
				<p>(2) EL BENEFICIO CONSISTE EN LA BONIFICACIÓN DE LA COMISIÓN DE MANTENIMIENTO MENSUAL DE SU PRODUCTO PATAGONIA, DURANTE LOS PRIMEROS 180 (CIENTO OCHENTA) DÍAS DESDE EL ALTA DE SU NUEVO PRODUCTO PATAGONIA. TRANSCURRIDO DICHO PODRA ACCEDER A LA BONIFICACION POR TRANSACCIONALIDAD O DEBERÁ ABONAR EL VALOR VIGENTE DE LA COMISIÓN CORRESPONDIENTE A SU PRODUCTO, EL CUAL PODRÁ SER CONSULTADO EN https://WWW.BANCO.PATAGONIA.COM.AR. Y EN CUALQUIERA DE NUESTRAS SUCURSALES.</p>
				<p>(3) CARTERA DE CONSUMO Y COMERCIAL PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/01/2025 HASTA EL 31/5/2025 AMBAS FECHAS INCLUIDAS, EXCLUSIVA PARA CLIENTES TITULARES DE LOS PRODUCTOS CUENTA MIX QUE ADHIERAN EL PAGO DE SU NUEVO PLAN DE SWISS MEDICAL AL DÉBITO AUTOMÁTICO DE SU TARJETA DE CRÉDITO O CUENTA VINCULADA SU PRODUCTO PATAGONIA CUENTA MIX.El BENEFICIO CONSISTE EN LA BONIFICACIÓN EL 25% DE DESCUENTO EN EL PAGO DE LA CUOTA DE LA COBERTURA MÉDICA DE SALUD BRINDADA POR SWISS MEDICAL - SIN TOPE DE REINTEGRO -, DURANTE LOS PRIMEROS 3 MESES DESDE EL ALTA DEL PLAN QUE CORRESPONDAEL CRÉDITO SE REALIZARÁ Y VISUALIZARÁ EN LA FACTURA DEL CLIENTE EMITIDA POR SWISS MEDICAL BAJO LA LEYENDA "Desc. Cliente Bco. Patagonia". NO APLICA A CLIENTES EXISTENTES DE SWISS MEDICAL. SUPERINTENDENCIA DE SERVICIOS DE SALUD - ÓRGANO DE CONTROL - 0800-222-SALUD (72583) - Superintendencia de Servicios de Salud - RNEMP N°. 1332.</p>
				<p>(3) CLUB PATAGONIA. PARA MÁS INFORMACIÓN CONSULTE EL REGLAMENTO DE CLUB PATAGONIA EN http://www.clubpatagonia.com.ar/ O ACERQUESE A CUALQUIERA DE NUESTRAS SUCURSALES.</p>
				<p>LOS ACCIONISTAS DE BANCO PATAGONIA S.A (CUIT 30-50000661-3, AV. DE MAYO 701, PISO 24, CABA), LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
            </div>
        </div>
	</section>
    <!-- FIN PRE FOOTER -->
	
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
            <!--<php if ($home_personas == false) { ?>
                <div class="col-sm-3 col-xs-3">
                    <a href="#"><span class="icon icon-contacto"></span></a>
                </div>
            <php } ?>-->
            			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../preguntas-frecuentes/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
	
	<!-- EXTERNAL LNK -->
    <div class="modal fade" id="wapa">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- -->
                <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
    <span class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt="Banco Patagonia"/></span>
</div>
<div class="modal-body">
    <div class="external-legend">
        <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios.</p>
    </div>
</div>                <!-- -->
                <div class="modal-footer">
                    <a href="https://www.wapa.com.ar" target="_blank" class="cta-btn">Aceptar</a>
                    <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
    <!-- FIN EXTERNAL LNK -->
	
</body>
</html>