
<!DOCTYPE HTML>
<html lang="es">
<head>
	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<title>Sumate a Patagonia ON | Una cuenta 100% online y gratis</title>
<meta name="description" content="Si tenés entre 18 y 28 años, abrí tu cuenta 100% online y gratis. Recibí hasta $10.000 de bienvenida y beneficios que la rompen.">

<!--<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">-->
<link rel="shortcut icon" href="favicon.ico" type="image/png">
<script src="assets/js/scrollreveal.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
<link href="assets/js/swiper-bundle.min.css" rel="stylesheet"/>
<link href="assets/css/layout.css" rel="stylesheet" type="text/css">

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '368520371362128');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=368520371362128&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MP4N9W2T');</script>
<!-- End Google Tag Manager -->

<!-- EN "TM" -->
<!-- Analytics -->
<!--<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z028NHBWBH"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-Z028NHBWBH'); </script>-->
<!-- END Analytics -->

<!-- TAG Google Ads -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-638747157"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-638747157');
</script>
<!-- End TAG Google Ads -->	
<!--<script src="https://unpkg.com/scrollreveal"></script>-->
        
<!-- Google -->
<meta name="thumbnail" content="https://www.bancopatagonia.com.ar/patagoniaon/assets/images/preview-patagonia-on.png" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="">
<meta property="og:title" content="Sumate a Patagonia ON | Una cuenta 100% online y gratis">
<meta property="og:description" content="Si tenés entre 18 y 28 años, abrí tu cuenta 100% online y gratis. Recibí hasta $10.000 de bienvenida y beneficios que la rompen.">
<meta property="og:image" content="https://www.bancopatagonia.com.ar/patagoniaon/assets/images/preview-patagonia-on.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="">
<meta property="twitter:title" content="Sumate a Patagonia ON | Una cuenta 100% online y gratis">
<meta property="twitter:description" content="Si tenés entre 18 y 28 aÃƒÂ±os, abrí tu cuenta 100% online y gratis. Recibí hasta $10.000 de bienvenida y beneficios que la rompen.">
<meta property="twitter:image" content="https://www.bancopatagonia.com.ar/patagoniaon/assets/images/preview-patagonia-on.png">

<!-- CSS -->
<style>
	@media screen and (max-width: 767px) {
		.hero__slide-4 .beneficios__box--right { background: none; }
		
	}
</style>
<!-- -->

</head>

<body>
	
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MP4N9W2T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<header class="header">
    <div class="container">
        <div class="header__cont">
            <div class="logo">
                <a href="index.php"><img src="assets/images/patagonia-on.svg" width="66" height="49" alt="Patagonia ON"></a>
            </div>
            <div class="navigation">
                <span class="lightmode toggle-lightmode"><img src="assets/images/light.svg" width="32" height="32" alt="Cambiar color"></span>
                <button class="hamburguer" aria-label="Abrir Menu">
                    <span class="hamburguer__line1"></span>
                    <span class="hamburguer__line2"></span>
                    <span class="hamburguer__line3"></span>
                </button>
            </div>
        </div>
    </div>
</header>
<nav class="navbar">
    <div class="container">
        <ul class="navbar__list">
            <li class="navbar__item"><a href="#bienvenida" class="internal anchorLink">Te damos la bienvenida a <br>Patagonia On</a></li>
            <li class="navbar__item"><a href="#ladoon" class="internal anchorLink">Activ&aacute; tu lado ON</a></li>
            <li class="navbar__item"><a href="beneficios.php">Beneficios con tus tarjetas</a></li>
            <li class="navbar__item"><a href="#billetera" class="internal anchorLink">Billetera digital</a></li>
            <li class="navbar__item"><a href="#rendir" class="internal anchorLink">Hac&eacute; rendir tu plata</a></li>
            <li class="navbar__item"><a href="#patagonia" class="internal anchorLink">Club Patagonia</a></li>
            <li class="navbar__item"><a href="patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
            <li class="navbar__item"><a href="#faq" class="internal anchorLink">Preguntas Frecuentes</a></li>
        </ul>
        <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/qr-code" class="btn"><span>Abr&iacute; tu cuenta <strong>Patagonia ON</strong></span></a>
    </div>
</nav>
<section class="hero" id="bienvenida">
    <div class="full-container">
        <div class="hero__swiper">
            <div class="swiper-wrapper">
				<div class="swiper-slide hero__slide-4">
                    <div class="container">
                        <h2 class="hero__title"><strong>BENEFICIOS EXCLUSIVOS</strong></h2>
                        <div class="beneficios__boxes">
                            <div class="beneficios__box beneficios__box--left">
                                <p class="beneficios__box-upper-text"><strong>Recibí de bienvenida hasta</strong></p>
                                <h3 class="beneficios__box-title"><strong>$20.000</strong></h3>
                                <!--<h4 class="beneficios__box-subtext"><strong>de regalo</strong></h4>-->
                                <p class="beneficios__box-text"><strong>Te devolvemos todas las compras que realices con tu tarjeta de débito, hasta alcanzar los $20.000 durante el primer mes <sup>(2)</sup></strong></p>
                            </div>
                            <div class="beneficios__plus">
                                <strong>+</strong>
                            </div>
                            <div class="beneficios__box beneficios__box--right">
								<p class="beneficios__box-upper-text"><strong>Ahorrá todos los meses hasta</strong></p>
                                <h3 class="beneficios__box-title"><strong>$100.000</strong></h3>
                                <p class="beneficios__box-text"><strong>por las compras que realices con nuestras tarjeta de débito y crédito en marcas adheridas <sup>(3)</sup></strong></p>
                            </div>
                        </div>
                        <div class="beneficio__cta"><a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--violet"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a></div>
                    </div>
                </div>
                <div class="swiper-slide hero__slide-1">
                    <div class="container">
                        <div class="hero__cont">
                            <div class="hero__image">                            
                                <div id="pinceladas"></div>
                                <div id="pinceladasdark"></div>
                            </div>
                            <div class="hero__data">
                                <h4 class="hero__text">Si tenés entre 18 y 28 años</h4>
                                <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--violet"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
                                <h2 class="hero__title">UNA CUENTA <strong>100% ONLINE Y GRATIS <sup>(1)</sup></strong></h2>
                                <h3 class="hero__text">Con tarjetas de débito y crédito que tienen beneficios que la rompen.</h3>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="swiper-slide hero__slide-2">
                    <div class="container">
                        <div class="hero__cont">
                            <div class="hero__image">
                                <div id="monedas"></div>
                            </div>
                            <div class="hero__data">
                                <h2 class="hero__title">BENEFICIO DE BIENVENIDA <strong>hasta $20.000 DE REGALO <sup>(2)</sup></strong></h2>
                                <h4 class="hero__text">Te devolvemos el 100% de tus compras con tarjeta de débito hasta alcanzar los $20.000 durante el primer mes.</h4>
                                <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--violet"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
                            </div>
                        </div>
                    </div>
                </div>-->
                <div class="swiper-slide hero__slide-3">
                    <div class="container">
                        <div class="hero__cont">
                            <div class="hero__image">
                                <div id="cuotifica"></div>
                            </div>
                             <div class="hero__data">
                                <figure class="hero__logo"><img src="assets/images/cuantifica.svg" width="324" height="182" alt="Cuotificá al toque"></figure>
                                <h2 class="hero__title">Si sos cliente ON</h2>
                                <h4 class="hero__text">Podés escanear cualquier QR y pagar en cuotas sin tarjetas ni saldo en cuenta <sup>(4)</sup></h4>
                                <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--violet"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hero__swiper-pagination"></div>
            <div class="hero__swiper-button hero__swiper-button-prev">
                <svg width="24" height="40" viewBox="0 0 24 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M-0.000463486 19.8746C0.0269966 19.0547 0.363371 18.2815 0.946875 17.6883L17.4223 1.02438C18.7403 -0.302063 20.9096 -0.348721 22.2826 0.931065C23.6487 2.21085 23.6967 4.31717 22.3787 5.65028L8.19607 20.0012L22.3718 34.3522C23.6898 35.6786 23.6487 37.7916 22.2757 39.0647C20.9096 40.3445 18.7335 40.2978 17.4154 38.9714L0.940012 22.3075C0.294724 21.6543 -0.0416508 20.7744 -0.00732613 19.8679L-0.000463486 19.8746Z" fill="#F89C33"/>
                </svg>
            </div>
            <div class="hero__swiper-button hero__swiper-button-next">
                <svg width="24" height="40" viewBox="0 0 24 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M-0.000463486 19.8746C0.0269966 19.0547 0.363371 18.2815 0.946875 17.6883L17.4223 1.02438C18.7403 -0.302063 20.9096 -0.348721 22.2826 0.931065C23.6487 2.21085 23.6967 4.31717 22.3787 5.65028L8.19607 20.0012L22.3718 34.3522C23.6898 35.6786 23.6487 37.7916 22.2757 39.0647C20.9096 40.3445 18.7335 40.2978 17.4154 38.9714L0.940012 22.3075C0.294724 21.6543 -0.0416508 20.7744 -0.00732613 19.8679L-0.000463486 19.8746Z" fill="#F89C33"/>
                </svg>
            </div>
        </div>
    </div>
</section>
    
<section class="activa" id="ladoon">
    <div class="container">
        <div class="activa__head">
            <div class="activa__head-text">
                <h2 class="activa__title">ACTIVÁ TU LADO ON</h2>
                <h4 class="activa__subtitle">con Banco Patagonia</h4>
                <p class="activa__text">y disfrutá de estas ventajas</p>
            </div>
            <div class="activa__image">
                <div id="tarjetas"></div>
            </div>
        </div>
        <ul class="activa__list">
            <li class="activa__item">
                <figure class="activa__icon"><img data-src="assets/images/activa-01.svg" width="60" height="44" class="activa__icon-1 lazy" alt="Cuenta completa con tarjeta de débito y crédito GRATIS."></figure>
                <p class="activa__item-text">Cuenta completa<br> con tarjeta de<br> débito y crédito<br> GRATIS.</p>
            </li>
            <li class="activa__item">
                <figure class="activa__icon"><img data-src="assets/images/activa-02.svg" width="46" height="57" class="activa__icon-2 lazy" alt="Tarjeta virtual. 100% online"></figure>
                <p class="activa__item-text">Tarjeta virtual. 100%<br> online, sin esperar a<br> que llegue el<br> plástico.</p>
            </li>
            <li class="activa__item">
                <figure class="activa__icon"><img data-src="assets/images/activa-03.svg" width="55" height="55" class="activa__icon-3 lazy" alt="Pagá desde cualquier QR en cuotas"></figure>
                <p class="activa__item-text">Pagá desde cualquier<br> QR en hasta 3 cuotas<br> fijas, sin necesidad de<br> tener dinero en <br>cuenta, con una tasa <br>exclusiva de 1%.</p>
            </li>
            <li class="activa__item">
                <figure class="activa__icon"><img data-src="assets/images/activa-04.svg" width="80" height="48" class="activa__icon-4 lazy" alt="Hasta $10.000 de bienvenida en tu 1era compra"></figure>
                <p class="activa__item-text"><strong>¡Recibí hasta $20.000<br> de Bienvenida en tu cuenta!</strong><br> Te devolvemos el 100% de todas tus compras con tarjeta de débito durante el primer mes.</p>
            </li>
            <li class="activa__item">
                <figure class="activa__icon"><img data-src="assets/images/activa-05.svg" width="60" height="60" class="activa__icon-5 lazy" alt="Preventa exclusivas para los mejores shows y recitales."></figure>
                <p class="activa__item-text">Preventa exclusivas<br> para los mejores<br> shows y recitales.</p>
            </li>
            <li class="activa__item">
                <figure class="activa__icon"><img data-src="assets/images/activa-06.svg" width="56" height="56" class="activa__icon-6 lazy" alt="Inversiones fáciles y al toque"></figure>
                <p class="activa__item-text">Inversiones fáciles y<br> al toque para hacer<br> rendir tu plata.<!--<br><strong>+ $5.000 extras<br> invertidos en Fondos<br> comunes de<br> inversión.</strong>--></p>
            </li>
        </ul>
        <div class="activa__cta">
            <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--dark"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
        </div>
        <p class="conoce">Conocé los beneficios 👇</p>
    </div> 
</section>
    
<section class="beneficios" id="beneficios">
    <div class="container">
        <h2 class="beneficios__title">BENEFICIOS</h2>
        <h3 class="beneficios__subtitle"><strong>DE HASTA 50% OFF</strong> EN TUS COMPRAS</h3>
        <div class="beneficios__cont">
            <div class="beneficios__data">
                <div class="beneficios__iconos">
                    <figure class="beneficios__icon bi1"><img src="assets/images/beneficio-01.svg" width="90" height="90" alt="música"></figure>
                    <figure class="beneficios__icon bi2"><img src="assets/images/beneficio-02.svg" width="90" height="90" alt="viajes"></figure>
                    <figure class="beneficios__icon bi3"><img src="assets/images/beneficio-03.svg" width="90" height="90" alt="entretenimiento"></figure>
                    <figure class="beneficios__icon bi4"><img src="assets/images/beneficio-04.svg" width="90" height="90" alt="supermercados"></figure>
                    <figure class="beneficios__icon bi5"><img src="assets/images/beneficio-05.svg" width="90" height="90" alt="gastronomía"></figure>
                </div>
                <p class="beneficios__text">En entretenimiento, supermercados, gastronomía, viajes, música y mucho más.</p>
            </div>
            <div class="beneficios__block">
                <div class="beneficios__bienvenida">
                    <div class="beneficios__bienvenida-group">
                        <div class="beneficios__bienvenida-head">
                            <figure class="beneficios__bienvenida-icon"><img data-src="assets/images/beneficio-regalo.svg" width="50" height="50" alt="Beneficio de bienvenida" class="lazy"></figure>
                            <!--<h4 class="beneficios__bienvenida-title"><strong>Beneficio de bienvenida</strong> HASTA $20.000 DE REGALO</h4>-->
							<h4 class="beneficios__bienvenida-title"><strong>Beneficio de bienvenida</strong> RECIBÍ HASTA $20.000</h4>
                        </div>
                        <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--violet btn--to--cyan"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
                    </div>
                    <p class="beneficios__bienvenida-text">Te devolvemos todas las compras que realices con tu tarjeta de débito, hasta alcanzar los $20.000 durante el primer mes <sup>(2)</sup></p>
                </div>
				<div class="beneficios__bienvenida">
                    <div class="beneficios__bienvenida-group">
                        <div class="beneficios__bienvenida-head">
                            <figure class="beneficios__bienvenida-icon"><img data-src="assets/images/beneficio-regalo.svg" width="50" height="50" alt="Beneficio de bienvenida" class="lazy"></figure>
                            <h4 class="beneficios__bienvenida-title">AHORRÁ HASTA $100.000</h4>
                        </div>
                        <!--<a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--violet btn--to--cyan"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>-->
                    </div>
                    <p class="beneficios__bienvenida-text">por las compras que realices con nuestras tarjeta de débito y crédito en marcas adheridas <sup>(3)</sup></p>
                </div>
                <!--<div class="beneficios__bienvenida">
                    <div class="beneficios__bienvenida-group">
                        <div class="beneficios__bienvenida-head">
                            <figure class="beneficios__bienvenida-icon"><img data-src="assets/images/beneficio-inversion.svg" width="45" height="45" alt="Beneficio de bienvenida" class="lazy"></figure>
                            <h4 class="beneficios__bienvenida-title"><strong>$ 5.000</strong> ya invertidos en tu primer <strong>FONDO LOMBARD</strong></h4>
                        </div>
                        <a href="../fondos/RG_Lombard_Renta_SFCI.pdf" target="_blank" class="btn btn--violet btn--to--cyan"><span>Consultá Reglamento</span></a>
                    </div>
                    <p class="beneficios__bienvenida-text">Y además te acompañamos en tu primera inversión.<br><a href="#reglamento" class="beneficio__show-modal">Ver más</a></p>
                </div>-->
            </div>
        </div>
        <h3 class="beneficios__destacados-title">BENEFICIOS DESTACADOS</h3>
    </div>
    <div class="beneficios__swiper">
        <div class="swiper-wrapper">
			<!-- ----------------- -->
            <!-- BARES Y FAST FOOD -->
            <!-- ----------------- -->
            <div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/bares-y-fastfood.svg" width="150" height="60" title="Bares y Fastfood" alt="Bares y Fastfood" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Los viernes con crédito Master</h4>
                <p class="beneficio__text">Tope: $5.000</p>
            </div>
			<!-- --- -->
            <!-- CUI -->
            <!-- --- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/cui.svg" width="150" height="60" title="CUI" alt="CUI" class="lazy"></figure>
                <h3 class="beneficio__off">15% off</h3>
                <h4 class="beneficio__title">Con débito y crédito Master</h4>
                <p class="beneficio__text">Todos los dias</p>
            </div>
			<!-- ------------ -->
            <!-- EDUCACIÓN IT -->
            <!-- ------------ -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/educacion-it.svg" width="150" height="60" title="Educación IT" alt="Educación IT" class="lazy"></figure>
                <h3 class="beneficio__off">50% off</h3>
                <h4 class="beneficio__title">Con débito y crédito Master</h4>
                <p class="beneficio__text">Todos los dias</p>
            </div>
			<!-- ------ -->
            <!-- TOPPER -->
            <!-- ------ -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/topper.svg" width="150" height="60" title="Topper" alt="Topper" class="lazy"></figure>
                <h3 class="beneficio__off">15% + 3 cuotas</h3>
                <h4 class="beneficio__title">Los jueves con débito y crédito Master</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- ------- -->
            <!-- SIMONES -->
            <!-- ------- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/simones.svg" width="150" height="60" title="Simones" alt="Simones" class="lazy"></figure>
                <h3 class="beneficio__off">15% + 3 cuotas</h3>
                <h4 class="beneficio__title">Los jueves</h4>
                <p class="beneficio__text">Tope $5.000</p>
            </div>-->
			<!-- -------------- -->
            <!-- PEDIDOS YA (1) -->
            <!-- -------------- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/pedidos-ya.svg" width="150" height="60" title="Pedidos Ya" alt="Pedidos Ya" class="lazy"></figure>
                <h3 class="beneficio__off">50% off</h3>
                <h4 class="beneficio__title">Los jueves con débito</h4>
                <p class="beneficio__text">Tope $1.500</p>
            </div>-->
			<!-- -------------- -->
            <!-- PEDIDOS YA (2) -->
            <!-- -------------- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/pedidos-ya.svg" width="150" height="60" title="Pedidos Ya" alt="Pedidos Ya" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Los jueves con crédito Master</h4>
                <p class="beneficio__text">Tope $4.000</p>
            </div>
			<!-- --------------- -->
            <!-- BURGER KING (1) -->
            <!-- --------------- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/burger-king.svg" width="150" height="60" title="Burger King" alt="Burger King" class="lazy"></figure>
                <h3 class="beneficio__off">50% off</h3>
                <h4 class="beneficio__title">Los viernes con débito</h4>
                <p class="beneficio__text">Tope $2.000</p>
            </div>-->
			<!--. Exclusivo <img src="assets/images/logo-modo.svg" width="63" height="20" title="MODO" alt="MODO">-->
			<!-- --------------- -->
            <!-- BURGER KING (2) -->
            <!-- --------------- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/burger-king.svg" width="150" height="60" title="Burger King" alt="Burger King" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Los miércoles con débito</h4>
                <p class="beneficio__text">Tope $1.000</p>
            </div>-->
			<!-- --------- -->
            <!-- CARREFOUR -->
            <!-- --------- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/carrefour.svg" width="150" height="60" title="Carrefour" alt="Carrefour" class="lazy"></figure>
                <h3 class="beneficio__off">15% off</h3>
                <h4 class="beneficio__title">Los miércoles con débito y crédito Master</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- ----------------------- -->
            <!-- FARMACIAS Y PERFUMERÍAS -->
            <!-- ----------------------- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/farmacias-y-perfumerias.svg" width="150" height="60" title="Farmacias y Perfumerías" alt="Farmacias y Perfumerías" class="lazy"></figure>
                <h3 class="beneficio__off">25% off</h3>
                <h4 class="beneficio__title">Del 4 al 6 de Noviembre</h4>
                <p class="beneficio__text">Tope $5.000</p>
            </div>-->
			<!-- -------------- -->
            <!-- CLUB PATAGONIA -->
            <!-- -------------- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/club-patagonia.svg" width="150" height="60" title="Club Patagonia" alt="Club Patagonia" class="lazy"></figure>
                <h3 class="beneficio__off">25% off</h3>
                <h4 class="beneficio__title">Todos los días</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>-->
			<!-- ----- -->
            <!-- CINES -->
            <!-- ----- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/cines.svg" width="150" height="60" title="Cines" alt="Cines" class="lazy"></figure>
                <h3 class="beneficio__off">50% off</h3>
                <h4 class="beneficio__title">Los viernes con débito</h4>
                <p class="beneficio__text">Tope $5.000</p>
            </div>
			<!-- ------ -->
            <!-- CABIFY -->
            <!-- ------ -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/cabify.svg" width="150" height="60" title="Cabify" alt="Cabify" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Todos los días con débito</h4>
                <p class="beneficio__text">Tope $5.000</p>
            </div>-->
			<!-- ------- -->
            <!-- HAVANNA -->
            <!-- ------- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/havanna.svg" width="150" height="60" title="Havanna" alt="Havanna" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Con crédito Master</h4>
                <p class="beneficio__text">Tope $6.000</p>
            </div>
			<!-- ----- -->
            <!-- COOPE -->
            <!-- ----- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/cooperativa-obrera.svg" width="150" height="60" title="Cooperativa Obrera" alt="Cooperativa Obrera" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Los jueves con crédito Master</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- ---- -->
            <!-- TODO -->
            <!-- ---- -->
			<!--<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/todo.svg" width="150" height="60" title="Todo" alt="Todo" class="lazy"></figure>
                <h3 class="beneficio__off">30% off</h3>
                <h4 class="beneficio__title">Los martes con crédito Master</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>-->
			<!-- ---------- -->
            <!-- CHANGO MAS -->
            <!-- ---------- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/chango-mas.svg" width="150" height="60" title="Chango Mas" alt="Chango Mas" class="lazy"></figure>
                <h3 class="beneficio__off">15% off</h3>
                <h4 class="beneficio__title">Los viernes con crédito Master</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- ------- -->
            <!-- RAPANUI -->
            <!-- ------- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/rapanui.svg" width="150" height="60" title="Rapanui" alt="Rapanui" class="lazy"></figure>
                <h3 class="beneficio__off">25% off</h3>
                <h4 class="beneficio__title">Los sábados y domingos del 01/04 al 30/06</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- ------- -->
            <!-- ATALAYA -->
            <!-- ------- -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/atalaya.svg" width="150" height="60" title="Atalaya" alt="Atalaya" class="lazy"></figure>
                <h3 class="beneficio__off">25% off</h3>
                <h4 class="beneficio__title">Los sábados y domingos del 01/04 al 30/06</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- ------ -->
            <!-- FREDDO -->
            <!-- ------ -->
			<div class="swiper-slide">
                <figure class="beneficio__logo"><img data-src="assets/images/logos/freddo.svg" width="150" height="60" title="Freddo" alt="Freddo" class="lazy"></figure>
                <h3 class="beneficio__off">25% off</h3>
                <h4 class="beneficio__title">Los sábados y domingos del 01/04 al 30/06</h4>
                <p class="beneficio__text">Tope $10.000</p>
            </div>
			<!-- -->
        </div>
        <div class="beneficios__swiper-pagination"></div>
    </div>
    <div class="container">
        <div class="beneficios__footer">
            <p class="beneficios__footer-text">Podés acceder a todos estos beneficios y muchos más. <strong>¡No te los podés perder!</strong></p>
            <div class="beneficios__cta">
                <!--<a href="beneficios.php" class="btn btn--violet btn--to--dark"><span><strong>Ver todos los beneficios</strong></span></a>-->
				<a href="https://ahorrosybeneficios.bancopatagonia.com.ar/on/inicio-on" target="_blank" class="btn btn--violet btn--to--dark"><span><strong>Ver todos los beneficios</strong></span></a>
            </div>            
        </div>
    </div>
</section>
    
<section class="app" id="billetera">
    <div class="container">
        <h2 class="app__title">HACE TODO DESDE NUESTRA APP</h2>
        <h3 class="app__subtitle">Bajate Patagonia Móvil, nuestra billetera digital</h3>
        <div class="app__grid">
            <div class="app__phone">
                <div class="app__phone-canvas">
                    <div class="app__phone-bg">
                        <div id="phonebg" class="phonebg"></div>
                        <div id="phonebg1" class="phonebg hidebg"></div>
                        <div id="phonebg2" class="phonebg hidebg"></div>
                        <div id="phonebg3" class="phonebg hidebg"></div>
                        <div id="phonebg4" class="phonebg hidebg"></div>
                        <div id="phonebg5" class="phonebg hidebg"></div>
                    </div>
                    <div class="app__phone-image">
                        <img data-src="assets/images/cellphone.webp" width="337" height="412" alt="movil" class="lazy">
                    </div>
                    <div class="app__swiper-container">
                        <div class="app__swiper">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="app__slide-1">
                                        <h5 class="app__slide-head">Pagá como quieras</h5>
                                        <h3 class="app__slide-title">PAGÁ COMO QUIERAS</h3>
                                        <p class="app__slide-text">Ahora tu celu es tu nueva billetera virtual</p>
                                        <ul class="app__slide-list">
                                            <li><img data-src="assets/images/google-pay.svg" width="66" height="31" alt="Google Pay" class="lazy"></li>
                                            <li><img data-src="assets/images/apple-pay.svg" width="66" height="27" alt="Apple Pay" class="lazy"></li>
                                            <li><img data-src="assets/images/modo.svg" width="86" height="31" alt="Google Pay" class="lazy"></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="app__slide-2">
                                        <h5 class="app__slide-head">Cuotificá al toque</h5>
                                        <h3 class="app__slide-title">CUOTIFICÁ AL TOQUE</h3>
                                        <p class="app__slide-text">Pagando en cuotas con cualquier QR desde la APP sin necesitar tarjeta de crédito ni plata en tu cuenta</p>
                                        <figure class="app__slide-image"><img src="assets/images/cuotifica.svg" width="94" height="94" alt="Cuotificá al toque"></figure>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="app__slide-3">
                                        <h5 class="app__slide-head">Enviá y pedí dinero a tus contactos</h5>
                                        <h3 class="app__slide-title">ENVIÁ Y PEDÍ DINERO A TUS CONTACTOS</h3>
                                        <p class="app__slide-text">Sin alias ni CBU, sólo con tu agenda de contactos.</p>
                                        <figure class="app__slide-image"><img src="assets/images/envia-pedi.png" width="121" height="107" alt="Enviá y pedí dinero a tus contactos"></figure>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="app__slide-4">
                                        <h5 class="app__slide-head">Ingresá dinero de otras cuentas</h5>
                                        <h3 class="app__slide-title">INGRESÁ DINERO DE OTRAS CUENTAS</h3>
                                        <p class="app__slide-text">Asociá tus cuentas de otros bancos y billeteras para tener tu plata en un solo lugar.</p>
                                        <figure class="app__slide-image"><img src="assets/images/ingresa-dinero.svg" width="88" height="88" alt="Ingresá dinero de otras cuentas"></figure>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="app__slide-5">
                                        <h5 class="app__slide-head">Recargá tu celu y tu SUBE</h5>
                                        <h3 class="app__slide-title">RECARGÁ TU CELU<br> Y TU SUBE</h3>
                                        <p class="app__slide-text">Cargá crédito y usalo cuando lo necesités.</p>
                                        <figure class="app__slide-image"><img src="assets/images/recarga-sube.svg" width="207" height="88" alt="Recargá tu celu y tu SUBE"></figure>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="app__slide-6">
                                        <h5 class="app__slide-head">Invertí fácil</h5>
                                        <h3 class="app__slide-title">INVERTÍ FÁCIL</h3>
                                        <p class="app__slide-text">Poné tu plata en movimiento y generá intereses al toque en muy pocos pasos.</p>
                                        <figure class="app__slide-image"><img src="assets/images/inverti-facil.svg" width="115" height="79" alt="Invertí fácil"></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="app__swiper-pagination"></div>
            </div>
            <div class="app__cont">
                <h4 class="app__cont-title">Bajate nuestra billetera digital</h4>
                <figure class="app__cont-pmovil"><img src="assets/images/patagonia-movil.svg" width="142" height="39" alt="Patagonia Movil"></figure>
                <div class="app__cont-apps">
                    <a href="https://apps.apple.com/ar/app/patagonia-m%C3%B3vil/id1178757002" target="_blank"><img src="assets/images/app-store.webp" width="139" height="39" alt="Disponible en App Store"></a>
                    <a href="https://play.google.com/store/apps/details?id=ar.com.bcopatagonia.android&hl=es_AR&gl=US" target="_blank"><img src="assets/images/google-play-store.webp" width="144" height="42" alt="Disponible en Google Play"></a>
                </div>
                <div class="app__cont-cta">
                    <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--dark"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
                </div>
            </div>
        </div>
    </div>    
</section>
    
<section class="rendir" id="rendir">
    <div class="container">
        <div class="rendir__heading">
            <div class="rendir__head">
                <h2 class="rendir__head-title">HACÉ RENDIR TU PLATA</h2>
                <h4 class="rendir__head-subtitle">fácil y rápido<sup>(5)</sup></h4>
            </div>
            <div class="rendir__image">
                <div id="plata"></div>
            </div>
        </div>
        <div class="rendir__cont">
            <div class="rendir__item rendir__item--left">
                <div class="rendir__item-head">
                    <figure class="rendir__item-icon"><img data-src="assets/images/fondo-comun.svg" width="106" height="90" alt="FONDO COMÚN DE INVERSIÓN" class="lazy"></figure>
                    <h3 class="rendir__item-title">FONDO COMÚN DE INVERSIÓN</h3>
                </div>
                <div class="rendir__item-text">
                    <p>Invertí al toque con tu fondo Lombard con rendimientos diarios.</p>
                    <p>En 2 clicks podés poner a rendir tu plata a diario y hacer retiros totales o parciales en el momento  y cuando quieras.</p>
                    <p>Opción para tus gastos diarios.</p>
                </div>
            </div>
            <div class="rendir__item rendir__item--right">
                <div class="rendir__item-head">
                    <figure class="rendir__item-icon"><img data-src="assets/images/plazo-fijo.svg" width="90" height="90" alt="PLAZO FIJO" class="lazy"></figure>
                    <h3 class="rendir__item-title">PLAZO FIJO</h3>
                </div>
                <div class="rendir__item-text">
                    <p>Depositás tu plata por 30 días y obtenés mayores ganancias.</p>
                    <p>Poné a rendir tus ahorros y ganá intereses, es super fácil.</p>
                </div>
            </div>
        </div>
        <div class="rendir__cta">
            <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--violet"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
        </div>
    </div>    
</section>
    
<section class="club" id="patagonia">
    <div class="container">
        <h2 class="club__title">Club patagonia</h2>
        <div class="club__cont">
            <ul class="club__cards">
                <li class="club__card club__card-01">
                    <figure class="club__card-icon"><img data-src="assets/images/cuotas-sin-interes.svg" width="50" height="38" alt="6 cuotas sin interés" class="lazy"></figure>
                    <div class="club__card-cont">
                        <h4 class="club__card-title">6 cuotas sin interés</h4>
                        <p class="club__card-text">En todos los productos, todos los días <sup>(6)</sup>.</p>
                    </div>
                </li>
                <li class="club__card club__card-02">
                    <figure class="club__card-icon"><img data-src="assets/images/como-pagar.svg" width="51" height="51" alt="Elegí cómo pagar" class="lazy"></figure>
                    <div class="club__card-cont">
                        <h4 class="club__card-title">Elegí cómo pagar</h4>
                        <p class="club__card-text">Pagá con puntos, pesos o combiná ambas opciones.</p>
                    </div>
                </li>
                <li class="club__card club__card-03">
                    <figure class="club__card-icon"><img data-src="assets/images/devoluciones-gratis.svg" width="54" height="50" alt="Devoluciones gratis" class="lazy"></figure>
                    <div class="club__card-cont">
                        <h4 class="club__card-title">Devoluciones gratis</h4>
                        <p class="club__card-text">Contás con 10 días para devolver tus productos gratis.</p>
                    </div>
                </li>
            </ul>
            <figure class="club__image">
                <img data-src="assets/images/club.webp" width="421" height="179" alt="Conocé nuestra tienda" class="lazy">
                <div id="club"></div>
            </figure>
            <h3 class="club__subtitle"><a href="https://www.clubpatagonia.com.ar/">Conocé nuestra tienda, donde podés comprar miles de productos con descuentos y cuotas</a></h3>
        </div>
        <div class="club__categorias">
            <h4 class="catagorias__title">Todas las <strong>categorías</strong></h4>
            <div class="categorias__todas">
                <ul class="categorias__list">
                    <li class="categorias__item">
                        <img data-src="assets/images/icon-entretenimiento.svg" width="116" height="119" title="Entretenimiento" alt="Entretenimiento" class="lazy">
                    </li>
                    <li class="categorias__item">
                        <img data-src="assets/images/icon-giftcards.svg" width="116" height="119" title="Gift Card" alt="Gift Card" class="lazy">
                    </li>
                    <li class="categorias__item">
                        <img data-src="assets/images/icon-productos.svg" width="116" height="119" title="Productos" alt="Productos" class="lazy">
                    </li>
                    <li class="categorias__item">
                        <img data-src="assets/images/icon-millas.svg" width="116" height="119" title="Millas" alt="Millas" class="lazy">
                    </li>
                    <li class="categorias__item">
                        <img data-src="assets/images/icon-credito.svg" width="116" height="119" title="Crédito en Tarjeta" alt="Crédito en Tarjeta" class="lazy">
                    </li>
                    <li class="categorias__item">
                        <img data-src="assets/images/icon-recargas.svg" width="116" height="119" title="Recargas" alt="Recargas" class="lazy">
                    </li>
                </ul>
                <h4 class="categorias__subtitle">Aprovechá los <strong>ENVÍOS GRATIS</strong> en productos seleccionados, todos los días.</h4>
            </div>
        </div>
        <div class="categorias__cta">
            <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--to--violet"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>
        </div>
    </div>    
</section>
    
<section class="faq" id="faq">
    <div class="medium-container">
        <h2 class="faq__title">PREGUNTAS FRECUENTES</h2>
        <div class="faq__container">
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Qué es Patagonia ON y a quién está dirigida?</h3>
                <div class="faq__content">
                    <p>Patagonia ON es una cuenta del Banco Patagonia diseñada para personas de 18 a 28 años.</p>
                </div>
            </div>
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Qué requisitos necesito para abrir una cuenta Patagonia ON?</h3>
                <div class="faq__content">
                    <p>Necesitás tener entre 18 y 28 años, DNI argentino válido y acceso a internet en tu celular.</p>
					<p>El proceso de apertura es totalmente gratis y 100% online.Solo deberás sacar fotos de tu DNI (frente y dorso) y una selfie para validar tu identidad.</p>
                </div>
            </div>
			<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿La cuenta Patagonia ON tiene costos de mantenimiento o comisiones?</h3>
                <div class="faq__content">
                    <p>No, la cuenta Patagonia ON no tiene costos ni comisiones mensuales. Además, podés retirar efectivo sin cargo en cajetos automáticos de Banco Patagonia.</p>
                </div>
            </div>
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Cómo genero mi clave de Patagonia Móvil e eBank por primera vez?</h3>
                <div class="faq__content">
                    <p>Desde Patagonia Móvil o eBank:</p>
					<p>Seleccioná la opción No tengo usuario/clave, o no lo recuerdo. > Ingresá tu tipo y número de documento. > Escribí el código de seguridad recibido en tu correo electrónico. > Respondé las preguntas de seguridad > Generá tu nuevo usuario y clave.</p>
                </div>
            </div>
			<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Cómo uso el Token Patagonia en la app Patagonia móvil?</h3>
                <div class="faq__content">
                    <p>Si ya activaste Token Patagonia desde un cajero automático, no necesitás ingresar claves adicionales en la app Todas las operaciones se validan automáticamente y de forma segura.</p>
					<p>#PadiTips: Si todavía no tenés Patagonia Móvil, descargala desde el store para tener el Banco en tu celular.</p>
                </div>
            </div>
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Desde qué momento puedo usar mi cuenta Patagonia ON?</h3>
                <div class="faq__content">
                    <p>Podés empezar a usar tu cuenta 48hs después de confirmar el alta y descargar la app Patagonia Móvil. Allí podrás ver tu tarjeta de débito digital y asociarla a Google Pay, Apple Pay o MODO para disfrutar de todos los beneficios que tenemos para vos.</p>
					<p>Visualizala desde: Menú > Tarjetas > Seleccioná la tarjeta de débito > Mostrar datos.</p>
                </div>
            </div>
			<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Qué operaciones puedo realizar con la cuenta Patagonia ON?</h3>
                <div class="faq__content">
                    <p>Podés transferir, pagar servicios, hacer compras online y en tiendas físicas con tu tarjetas de débito o crédito. También podés retirar dinero en efectivo en cajeros automáticos y realizar inversiones a través de la app para hacer rendir tu dinero.</p>
                </div>
            </div>
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Qué beneficios me ofrece la cuenta Patagonia ON?</h3>
                <div class="faq__content">
                    <p>Incluye beneficios de bienvenida, descuentos exclusivos en comercios, espectáculos y shows, la posibilidad de obtener una tarjeta de crédito sin cargo y cuotificar tus compras sin necesitar saldo en cuenta. Además, te damos tu primera inversión en fondos Lombard para que maximices tu dinero.</p>
                </div>
            </div>
			<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Cómo uso el beneficio de bienvenida?</h3>
                <div class="faq__content">
                    <p>Desde el momento en que abrís tu cuenta Patagonia ON y durante un mes, tenés un 100% de descuento en todas las compras con tarjeta de débito, cualquier día de la semana. Te devolvemos hasta $20.000. Este beneficio también puede usarse con la tarjeta de débito digital.</p>
                </div>
            </div>
            <!--<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Cómo uso mi primera inversión?</h3>
                <div class="faq__content">
                    <p>Desde el momento en que abrís tu cuenta Patagonia On te damos $5.000 en un Fondo Lombard Renta en pesos para que te inicies en el mundo de inversiones. Para agregar más dinero, Ingresá en el Fondo de Inversión desde el cual vas a realizar la operación y presioná la opción Suscribir > Seleccioná la cuenta a debitar > Digitá el importe y presioná Siguiente > Descargá los documentos de la operación y si los datos son correctos, seleccioná Confirmar.</p>
                </div>
            </div>-->
			<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Dónde me comunico si tengo alguna consulta?</h3>
                <div class="faq__content">
                    <p>Podés chatear con Padi nuestro asistente virtual, que está disponible para vos todos los días, las 24 horas a través de Patagonia Móvil, Patagonia eBank o whatsapp al 5491156350000. Si necesitás más ayuda, también podés llamar al Centro de Contacto al 0800 777 8500 de lunes a viernes de 8 a 20hs.</p>
                </div>
            </div>
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Qué tipo de tarjetas incluye la cuenta Patagonia ON?</h3>
                <div class="faq__content">
                    <p>Incluye una tarjeta de débito y, en el caso que califiques crediticiamente, una tarjeta de crédito Mastercard Internacional sin costo. </p>
                </div>
            </div>
			<div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Cómo cuotifico mis compras?</h3>
                <div class="faq__content">
                    <p>Podés pagar en cuotas con una tasa preferencial todas compras que realices con QR, sin necesitar tener saldo en la cuenta ni tarjeta de crédito.</p>
                </div>
            </div>
            <div class="faq__item">
                <h3 class="faq__question js-accordion-open">¿Cómo activo mi tarjeta de crédito MasterCard Patagonia ON?</h3>
                <div class="faq__content">
                    <p>Llamá a Mastercard al (011) 4340-5700 o al 0810-999-5700 para activarla.</p>
					<p>Si tenés alguna otra duda, ingresá <a href="https://www.bancopatagonia.com.ar/preguntas-frecuentes/cliente/alta-online/index.php" target="_blank">acá</a>.</p>
                </div>
            </div>
        </div>
        <div class="faq__cta">
            <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" class="btn btn--violet btn--to--cyan"><span>Abrí tu cuenta <strong>Patagonia ON</strong></span></a>

        </div>
    </div>    
</section>
    
<section class="legales">
    <div class="medium-container">
        <!--<p>(1) Una cuenta 100% on line y gratis</p>-->
		<p>(1) CARTERA DE CONSUMO – PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 1/4/2025 HASTA EL 30/06/2025, AMBAS FECHAS INCLUIDAS, EXCLUSIVA PARA LOS PRODUCTOS CAJA DE AHORRO GRATUITA Y PATAGONIA ON. EL OTORGAMIENTO DE LOS PRODUCTOS Y SERVICIOS DE BANCO PATAGONIA S.A. SE ENCUENTRA SUJETO A LA APROBACIÓN DE LAS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DE DICHA ENTIDAD. PARA MÁS INFORMACIÓN ACERCATE A CUALQUIERA DE NUESTRAS SUCURSALES.</p>
		<p>(2) CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/04/2025 HASTA EL 30/06/2025, AMBAS FECHAS INCLUIDAS.NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO CONSISTE EN LA BONIFICACIÓN POR ÚNICA VEZ DEL 100% DE CUALQUIER CONSUMO EFECTUADO/S CON LA TARJETA DE DÉBITO PATAGONIA24 EMITIDA POR BANCO PATAGONIA S.A, EN COMERCIOS DE ARGENTINA DENTRO DE LOS 30 (TREINTA) DÍAS DE LA FECHA DEL ALTA DE DICHA TARJETA, HASTA ALCANZAR UN TOPE TOTAL DE REINTEGRO DE $20.000 (PESOS VEINTE MIL.</p>
		<p>(3) CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/04/2025 HASTA EL 30/06/2025, AMBAS FECHAS INCLUIDAS. EL CLIENTE PODRÁ RECIBIR UNA DEVOLUCIÓN TOTAL MENSUAL POR TODAS LAS COMPRAS QUE REALICE CON SUS TARJETAS DE DÉBITO Y/O CRÉDITO EMITIDAS POR BANCO PATAGONIA EN LOS COMERCIOS ADHERIDOS Y ESPECIFICADOS EN ESTA PÁGINA WEB EN LA SECCIÓN DE BENEFICIOS. https://www.bancopatagonia.com.ar/patagoniaon. LA DEVOLUCIÓN TOTAL DE LOS $100.000 CORRESPONDE A LA SUMATORIA DE LOS TOPES DE CADA MARCA Y/O RUBRO. BANCO PATAGONIA S.A. NUNCA LE SOLICITARA QUE REVELE SUS CLAVES POR NINGÚN MEDIO. SI RECIBE UN E-MAIL O UN LLAMADO TELEFÓNICO SOLICITÁNDOLE SUS CLAVES PERSONALES, NO LO RESPONDA. NUNCA REVELE SUS CLAVES, DATOS PERSONALES O NÚMEROS DE CUENTA BANCARIAS BAJO NINGÚN CONCEPTO. UD. HA RECIBIDO ESTE MENSAJE PORQUE LA EMPRESA QUE LO REMITE CONSIDERA QUE PUEDE SER INFORMACIÓN DE SU INTERÉS. LEY 25.326, ART. 27 INC. 3): EL TITULAR PODRÁ EN CUALQUIER MOMENTO SOLICITAR EL RETIRO O BLOQUEO TOTAL O PARCIAL DE SU NOMBRE DE LOS BANCOS DE DATOS A LOS QUE SE REFIERE EL PRESENTE ARTÍCULO. ASIMISMO, TIENE LA FACULTAD DE EJERCER EL DERECHO DE ACCESO EN FORMA GRATUITA A INTERVALOS NO INFERIORES A 6 MESES. ART. 14 INC. 3) LEY 25.326 LA DIRECCIÓN NACIONAL DE PROTECCIÓN DE DATOS PERSONALES TIENE LA ATRIBUCIÓN DE ATENDER DENUNCIAS Y RECLAMOS RELATIVOS AL INCUMPLIMIENTO DE NORMAS SOBRE PROTECCIÓN DE DATOS PERSONALES. BANCO PATAGONIA S.A. ASUME EL CARÁCTER DE RESPONSABLE REGISTRADO YA QUE HA CUMPLIMENTADO CON TODOS LOS REQUISITOS QUE EXIGE ESTA LEY. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661-3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
		<p>(4) CARTERA DE CONSUMO.EL OTORGAMIENTO DEL PRÉSTAMO SE ENCUENTRA SUJETO A LA APROBACIÓN DE SUS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DISPUESTAS POR BANCO PATAGONIA S.A., LAS CUALES PODRÁN SER CONSULTADAS EN PATAGONIA Móvil ANTES DE SU ACEPTACIÓN, EN WWW. Banco Patagonia | Vos y lo que querés Y EN CUALQUIERA DE NUESTRAS SUCURSALES. IMPORTE MÁXIMO A OTORGAR PARA PRÉSTAMOS SOLICITADOS POR PATAGONIA MÓVIL: HASTA $150.000 (PESOS CIENTO CINCUENTA MIL). LA ACREDITACIÓN DEL MONTO DEL PRÉSTAMO SE EFECTUARÁ EN SU CAJA DE AHORRO EN PESOS. EL CAPITAL DEBERÁ SER REEMBOLSADO EN CUOTAS MENSUALES Y CONSECUTIVAS. EL IMPORTE DE CADA CUOTA RESULTARÁ DE APLICAR EL “SISTEMA DE AMORTIZACIÓN FRANCÉS” DE INTERÉS SIMPLE E INCLUIRÁ LOS INTERESES COMPENSATORIOS A LA TASA PACTADA, EL I.V.A. Y LOS IMPUESTOS LOCALES QUE PUDIERAN CORRESPONDER DE ACUERDO CON LA JURISDICCIÓN DEL CLIENTE. PARA UTILIZAR PATAGONIA MÓVIL DEBERÁ: (I) ENCONTRARSE PREVIAMENTE ADHERIDO A PATAGONIAEBANK; (II) POSEER UN TELÉFONO CELULAR CON SISTEMA OPERATIVO ANDROID O IOS (IPHONE) CON ACCESO A INTERNET Y SERVICIO DE DATOS; (III) ACEPTAR PREVIAMENTE SUS TÉRMINOS Y CONDICIONES, LOS CUALES PODRÁN SER CONSULTADOS EN Banco Patagonia | Vos y lo que querés O EN CUALQUIERA DE NUESTRAS SUCURSALES. SIEMPRE DESCARGUE LA APLICACIÓN DE TIENDAS OFICIALES, NO ACCEDA DESDE LINKS QUE PROVENGAN DE MAILS O SMS. LOS COSTOS DE LA DESCARGA, DEL USO DE LA APLICACIÓN Y EL DE LA NAVEGACIÓN, SERÁN LOS QUE COBRE LA EMPRESA DE TELEFONÍA CELULAR UTILIZADA POR EL CLIENTE Y SERÁN A SU EXCLUSIVO CARGO. BANCO PATAGONIA S.A. NO SERÁ RESPONSABLE POR LOS ERRORES EN EL SOFTWARE DE LA APLICACIÓN, NI POR LA SUSPENSIÓN, INTERRUPCIÓN O FALLA DEL SERVICIO PROVENIENTE DE UNA MEDIDA UNILATERAL DE SU EMPRESA DE TELEFONÍA CELULAR.</p>
		<p>(5) LOS DEPÓSITOS EN PESOS Y EN MONEDA EXTRANJERA CUENTAN CON LA GARANTÍA DE HASTA $ 25.000.000. EN LAS OPERACIONES A NOMBRE DE DOS O MÁS PERSONAS, LA GARANTÍA SE PRORRATEARÁ ENTRE SUS TITULARES. EN NINGÚN CASO, EL TOTAL DE LA GARANTÍA POR PERSONA Y POR DEPÓSITO PODRÁ EXCEDER DE $ 25.000.000, CUALQUIERA SEA EL NÚMERO DE CUENTAS Y/O DEPÓSITOS. LEY 24.485, DECRETO Nº 540/95 Y MODIFICATORIOS Y COM. “A” 2337 Y SUS MODIFICATORIAS Y COMPLEMENTARIAS. SE ENCUENTRAN EXCLUIDOS LOS CAPTADOS A TASAS SUPERIORES A LA DE REFERENCIA CONFORME A LOS LÍMITES ESTABLECIDOS POR EL BANCO CENTRAL, LOS ADQUIRIDOS POR ENDOSO Y LOS EFECTUADOS POR PERSONAS VINCULADAS A LA ENTIDAD FINANCIERA. LAS INVERSIONES EN CUOTAS DEL FONDO NO CONSTITUYEN DEPÓSITOS EN BANCO PATAGONIA S.A. A LOS FINES DE LEY DE ENTIDADES FINANCIERAS NI CUENTAN CON NINGUNA DE LAS GARANTÍAS QUE TALES DEPÓSITOS A LA VISTA O A PLAZOS PUEDAN GOZAR DE ACUERDO CON LA LEGISLACIÓN Y REGLAMENTACIÓN APLICABLES EN MATERIA DE DEPÓSITOS EN ENTIDADES FINANCIERAS. ASIMISMO, BANCO PATAGONIA S.A. SE ENCUENTRA IMPEDIDO POR NORMAS DEL BANCO CENTRAL DE LA REPÚBLICA ARGENTINA DE ASUMIR, TÁCITA O EXPRESAMENTE, COMPROMISO ALGUNO EN CUANTO AL MANTENIMIENTO, EN CUALQUIER MOMENTO, DEL VALOR DEL CAPITAL INVERTIDO, AL RENDIMIENTO, AL VALOR DEL RESCATE DE LAS CUOTAS PARTES O AL OTORGAMIENTO DE LIQUIDEZ A TAL FIN, PATAGONIA INVERSORA SE ENCUENTRA REGISTRADO ANTE LA COMISION NACIONAL DE VALORES COMO AGENTE DE ADMINISTRACIÓN DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO EL Nº 14, POR SU PARTE, BANCO PATAGONIA S.A. SE ENCUENTRA REGISTRADO ANTE LA COMISIÓN NACIONAL DE VALORES COMO AGENTE DE CUSTODIA DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO ELNRO 23.</p>
		<p>(6) CARTERA DE CONSUMO Y COMERCIAL – PROMOCIÓN VALIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/04/2025 HASTA EL 30/04/2025, AMBAS FECHAS INCLUÍDAS, EXCLUSIVA PARA CLIENTES TITULARES DE LOS PRODUCTOS PATAGONIA CLASICA, PLUS Y SINGULAR EMITIDAS POR BANCO PATAGONIA S.A. RECIBIRÁN UNA FINANCIACIÓN EN HASTA 6 (SEIS) CUOTAS SIN INTERÉS POR LA/S COMPRA/S QUE REALICEN EN LA TIENDA CLUB PATAGONIA CON SU/S TARJETAS DE CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS – CARTERA DE CONSUMO – SE APLICARÁ: TASA NOMINAL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO FINANCIERO TOTAL NOMINAL ANUAL (*).</p>
		<p style="font-size: 5em;">C.F.T.N.A (CON Y SIN IVA):<br>
		(*)0,00%;<br>
		(**)4,34%</p>
		<p>BANCO PATAGONIA NUNCA LE SOLICITARÁ QUE REVELE SUS CLAVES POR NINGÚN MEDIO. SI RECIBE UN E-MAIL O UN LLAMADO TELEFÓNICO SOLICITÁNDOLE SUS CLAVES PERSONALES, NO LO RESPONDA. NUNCA REVELE SUS CLAVES, DATOS PERSONALES O NÚMEROS DE CUENTAS BANCARIAS BAJO NINGÚN CONCEPTO. UD. HA RECIBIDO ESTE MENSAJE PORQUE LA EMPRESA QUE LO REMITE CONSIDERA QUE PUEDE SER INFORMACIÓN DE SU INTERÉS. LEY 25.326, ART. 27, INC. 3: EL TITULAR PODRÁ EN CUALQUIER MOMENTO SOLICITAR EL RETIRO O BLOQUEO TOTAL A O PARCIAL DE SU NOMBRE DE LOS BANCOS DE DATOS A LOS QUE SE REFIERE EL PRESENTE ARTÍCULO. ASIMISMO, TIENE LA FACULTAD DE EJERCER EL DERECHO DE ACCESO EN FORMA GRATUITA A INTERVALOS NO INFERIORES A 6 MESES. ART. 14 INC. 3) LEY 25.326: LLA DIRECCIÓN NACIONAL DE PROTECCIÓN DE DATOS PERSONALES TIENE LA ATRIBUCIÓN DE ATENDER DENUNCIAS Y RECLAMOS RELATIVOS AL INCUMPLIMIENTO DE NORMAS SOBRE PROTECCIÓN DE DATOS PERSONALES. BANCO PATAGONIA S.A. ASUME EL CARÁCTER DE RESPONSABLE REGISTRADO YA QUE HA CUMPLIMENTADO CON TODOS LOS REQUISITOS QUE EXIGE ESTA LEY. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661- 3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
        <p>© 2025 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación, distribución o almacenamiento en cualquier medio.</p>
    </div>    
</section>
    
<!-- MODAL -->
<div class="modal__beneficio" id="reglamento">
    <div class="modal__inner">
        <div class="modal__card">
            <button class="modal__close" aria-label="Cerrar Modal"></button>
            <div class="modal__body">
                <h2 class="modal__title">Términos y condiciones Fondo Lombard</h2>
                <div class="modal__content">
                    <p>(1) CARTERA DE CONSUMO. PROMOCIÓN VALIDA EN LA REPÚBLICA ARGENTINA DESDE EL 23/09/2024 HASTA EL 31/12/2024 AMBAS FECHAS INCLUIDAS O HASTA AGOTAR STOCK DE 15.000 ALTAS DE CUENTAS. EL BENEFICIO CONSISTE EN LA ACREDITACIÓN DE $5.000 (PESOS CINCO MIL), POR UNICA VEZ, EN CUOTAPARTES DEL FONDO COMUN DE INVERSIÓN DENOMINADO “LOMBARD RENTA EN PESOS”, LUEGO DE LOS 5 DIAS HABILES DE ACEPTADO EL PRESENTE BENEFICIO. ASIMISMO, LE RECORDAMOS QUE PODRÁ RESCATAR SUS CUOTAPARTES A TRAVES DE PATAGONIAeBANK O A TRAVES DE PATAGONIA MOVIL Y QUE EL IMPORTE CORRESPONDIENTE SE ACREDITARÁ EN SU CAJA DE AHORROS, CONFORME EL VALOR DE CIERRE DE LA CUOTAPARTE DEL DIA EN QUE REALIZA EL RESCATE. BENEFICIO EXCLUSIVO A TRAVES DEL CANAL DIGITAL. (*) VER REGLAMENTO DE FONDOS LOMBARD RENTA EN PESOS: HTTPS://BANCOPATAGONIA.COM.AR/FONDOS/RG_LOMBARD_RENTA_SFCI.PDF. BANCO PATAGONIA S.A. INTERVIENE EN SU CARÁCTER DE AGENTE DE CUSTODIA DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN INSCRIPTO ANTE LA CNV BAJO EL N° 23. PATAGONIA INVERSORA S.A.G.F.C.I. SE ENCUENTRA REGISTRADO ANTE LA COMISIÓN NACIONAL DE VALORES COMO AGENTE DE ADMINISTRACIÓN DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO EL N°14. LAS INVERSIONES EN CUOTAS DEL FONDO NO CONSTITUYEN DEPÓSITOS EN EL BANCO PATAGONIA S.A. A LOS FINES DE LA LEY DE ENTIDADES FINANCIERAS, NI CUENTAN CON NINGUNA DE LAS GARANTÍAS QUE TALES DEPÓSITOS A LA VISTA O A PLAZO PUEDAN GOZAR DE ACUERDO CON LA LEGISLACIÓN Y REGLAMENTACIÓN APLICABLES EN MATERIA DE DEPÓSITOS EN ENTIDADES FINANCIERAS. ASIMISMO, BANCO PATAGONIA S.A. SE ENCUENTRA IMPEDIDO POR NORMAS DEL BANCO CENTRAL DE LA REPUBLICA ARGENTINA DE ASUMIR, TÁCITA O EXPRESAMENTE, COMPROMISO ALGUNO EN CUANTO AL MANTENIMIENTO, EN CUALQUIER MOMENTO, DEL VALOR DEL CAPITAL INVERTIDO, AL RENDIMIENTO, AL VALOR DE RESCATE DE LAS CUOTAPARTES O AL OTORGAMIENTO DE LIQUIDEZ A TAL FIN. LAS INSTRUCCIONES CURSADAS A TRAVÉS DEL PRESENTE CORREO ELECTRÓNICO Y LOS ACTOS Y TRANSACCIONES QUE EN CUMPLIMIENTO DE LAS MISMAS SEAN EJECUTADAS POR EL BANCO, SERÁN CONSIDERADOS POR ÉSTE A TODOS LOS EFECTOS LEGALES COMO REALIZADOS POR EL CLIENTE. EL BANCO NO SE ENCONTRARÁ OBLIGADO, EN NINGUNA CIRCUNSTANCIA, A VERIFICAR LA IDENTIDAD O FACULTADES DEL CLIENTE NI LA AUTENTICIDAD DEL MAIL, SIENDO EL CLIENTE EL ÚNICO RESPONSABLE POR EL USO DEL CORREO ELECTRÓNICO. BANCO PATAGONIA S.A. NUNCA LE SOLICITARA QUE REVELE SUS CLAVES POR NINGÚN MEDIO. SI RECIBE UN E-MAIL O UN LLAMADO TELEFÓNICO SOLICITÁNDOLE SUS CLAVES PERSONALES, NO LO RESPONDA. NUNCA REVELE SUS CLAVES, DATOS PERSONALES O NÚMEROS DE CUENTA BANCARIAS BAJO NINGÚN CONCEPTO. UD. HA RECIBIDO ESTE MENSAJE PORQUE LA EMPRESA QUE LO REMITE CONSIDERA QUE PUEDE SER INFORMACIÓN DE SU INTERÉS. LEY 25.326, ART. 27 INC. 3): EL TITULAR PODRÁ EN CUALQUIER MOMENTO SOLICITAR EL RETIRO O BLOQUEO TOTAL O PARCIAL DE SU NOMBRE DE LOS BANCOS DE DATOS A LOS QUE SE REFIERE EL PRESENTE ARTÍCULO. ASIMISMO, TIENE LA FACULTAD DE EJERCER EL DERECHO DE ACCESO EN FORMA GRATUITA A INTERVALOS NO INFERIORES A 6 MESES. ART. 14 INC. 3) LEY 25.326 LA DIRECCIÓN NACIONAL DE PROTECCIÓN DE DATOS PERSONALES TIENE LA ATRIBUCIÓN DE ATENDER DENUNCIAS Y RECLAMOS RELATIVOS AL INCUMPLIMIENTO DE NORMAS SOBRE PROTECCIÓN DE DATOS PERSONALES. BANCO PATAGONIA S.A. ASUME EL CARÁCTER DE RESPONSABLE REGISTRADO YA QUE HA CUMPLIMENTADO CON TODOS LOS REQUISITOS QUE EXIGE ESTA LEY. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661-3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- FIN MODAL -->
    
<script type="text/javascript" src="assets/js/jquery-3.7.1.min.js"></script>
<script src="assets/js/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.12.2/lottie.min.js" type="text/javascript"></script>
<script type="text/javascript" src="assets/js/lazyload.min.js"></script>
<script type="text/javascript" src="assets/js/js.js"></script>
<script>
    
var pinceladas = bodymovin.loadAnimation({
  container: document.getElementById('pinceladas'), // Required
  path: 'assets/lotties/Manos_Lottie-pinceladas-40-image-ratio-508x565-fondo-azul.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Pinceladas", // Name for future reference. Optional.
})

var pinceladasdark = bodymovin.loadAnimation({
  container: document.getElementById('pinceladasdark'), // Required
  path: 'assets/lotties/Manos_Lottie-pinceladas-40-image-ratio-508x565-fondo-negro.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "PinceladasDark", // Name for future reference. Optional.
})

var monedas = bodymovin.loadAnimation({
  container: document.getElementById('monedas'), // Required
  path: 'assets/lotties/Lottie-chica-monedas-60-ratio-image-530x460.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Monedas", // Name for future reference. Optional.
})

var cuotifica = bodymovin.loadAnimation({
  container: document.getElementById('cuotifica'), // Required
  path: 'assets/lotties/Lottie-cuotifica-60-image-ratio-522x470.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Monedas", // Name for future reference. Optional.
})

var tarjetas = bodymovin.loadAnimation({
  container: document.getElementById('tarjetas'), // Required
  path: 'assets/lotties/Tarjetas-x2-40-image-ratio-550x400.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Tarjetas", // Name for future reference. Optional.
})

var club = bodymovin.loadAnimation({
  container: document.getElementById('club'), // Required
  path: 'assets/lotties/Tarjetas-Club-Patagonia-60-image-ratio-170x180.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club", // Name for future reference. Optional.
})

var plata = bodymovin.loadAnimation({
  container: document.getElementById('plata'), // Required
  path: 'assets/lotties/Lottie-Mobile-App-40-ratio-image-340x415-old-versions.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club", // Name for future reference. Optional.
})

var phonebg = bodymovin.loadAnimation({
  container: document.getElementById('phonebg'), // Required
  path: 'assets/lotties/Lottie-Billetera-comoquieras-400x444.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club", // Name for future reference. Optional.
})

var phonebg1 = bodymovin.loadAnimation({
  container: document.getElementById('phonebg1'), // Required
  path: 'assets/lotties/Lottie-Billetera-sintarjeta-400x444-fondo-transparente-include-old-versions.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club2", // Name for future reference. Optional.
})

var phonebg2 = bodymovin.loadAnimation({
  container: document.getElementById('phonebg2'), // Required
  path: 'assets/lotties/Lottie-Billetera-sinalias-400x444-fondo-transparente-include-old-versions.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club3", // Name for future reference. Optional.
})

var phonebg3 = bodymovin.loadAnimation({
  container: document.getElementById('phonebg3'), // Required
  path: 'assets/lotties/Lottie-Billetera-ingresadinero-400x444-fondo-transparente-include-old-versions.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club4", // Name for future reference. Optional.
})

var phonebg4 = bodymovin.loadAnimation({
  container: document.getElementById('phonebg4'), // Required
  path: 'assets/lotties/Lottie-Billetera-recarga-400x444-fondo-transparente-include-old-versions.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club4", // Name for future reference. Optional.
})

var phonebg5 = bodymovin.loadAnimation({
  container: document.getElementById('phonebg5'), // Required
  path: 'assets/lotties/Lottie-Billetera-inversiones-400x444-fondo-transparente-include-old-versions.json', // Required
  renderer: 'canvas', // Required
  loop: true, // Optional
  autoplay: true, // Optional
  name: "Club4", // Name for future reference. Optional.
})
    
</script>
</body>
</html>