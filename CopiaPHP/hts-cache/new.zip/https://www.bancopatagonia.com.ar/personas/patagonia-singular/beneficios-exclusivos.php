<!DOCTYPE html>
<html lang="es">
<head>
<script type="text/javascript">
window.location = "https://ahorrosybeneficios.bancopatagonia.com.ar/singular/inicio-singular";
</script>
</head>
<body>
</body>
</html>